package com.example.my_e_commerece_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
